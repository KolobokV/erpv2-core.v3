Param(
    [string]$DolibarrRoot = "..\ERP_Doli17_PresetAdmin_DockerHubOnly",
    [string]$ApiKeyFileRel = "init\api_key.txt",
    [string]$ApiKeyFile = "",
    [switch]$Rebuild
)
$ErrorActionPreference = "Stop"
Write-Host "== ERPv2_backend_connect : bootstrap =="

function Resolve-ExistingPath {
    param([string]$p)
    try {
        if ([string]::IsNullOrWhiteSpace($p)) { return $null }
        $rp = Resolve-Path -LiteralPath $p -ErrorAction SilentlyContinue
        if ($rp) { return $rp.Path }
    } catch {}
    return $null
}

$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $scriptDir\..

if (-not (Get-Command docker -ErrorAction SilentlyContinue)) { throw "Docker is not installed or not in PATH." }

$baseUrl = "http://localhost:8282"
$apiUrl  = "$baseUrl/api/index.php"
Write-Host " - Probing Dolibarr at $baseUrl"
try {
    $resp = Invoke-WebRequest "$baseUrl" -UseBasicParsing -TimeoutSec 5
    Write-Host "   Dolibarr web reachable: $($resp.StatusCode)"
} catch {
    Write-Warning "   Dolibarr web not reachable yet. Continue anyway..."
}

$keyString = $null
$keyPath   = $null
if ($ApiKeyFile) {
    $p = Resolve-ExistingPath $ApiKeyFile
    if ($p) { $keyPath = $p }
}
if (-not $keyPath) {
    $candidate = Join-Path $DolibarrRoot $ApiKeyFileRel
    $p = Resolve-ExistingPath $candidate
    if ($p) { $keyPath = $p }
}
if (-not $keyPath -and (Test-Path $DolibarrRoot)) {
    $found = Get-ChildItem -Path $DolibarrRoot -Filter "api_key.txt" -File -Recurse -ErrorAction SilentlyContinue | Select-Object -First 1
    if ($found) { $keyPath = $found.FullName }
}
if (-not $keyPath -and $env:DOLI_API_KEY) {
    $keyString = $env:DOLI_API_KEY.Trim()
}
if (-not $keyPath -and -not $keyString) {
    throw "Dolibarr API key not found. Provide -ApiKeyFile or set DOLI_API_KEY env."
}

$envPath = ".\.env"
if ($keyPath) {
@"
DOLI_BASE_URL=$apiUrl
DOLI_API_KEY_PATH=$keyPath
"@ | Out-File -FilePath $envPath -Encoding UTF8 -Force
Write-Host " - .env written with DOLI_API_KEY_PATH -> $keyPath"
} else {
@"
DOLI_BASE_URL=$apiUrl
DOLI_API_KEY=$keyString
"@ | Out-File -FilePath $envPath -Encoding UTF8 -Force
Write-Host " - .env written with DOLI_API_KEY from env"
}

if ($Rebuild) {
    Write-Host " - docker compose build --no-cache"
    docker compose build --no-cache
}
Write-Host " - docker compose up -d"
docker compose up -d

$health = "http://localhost:8000/health"
Write-Host " - Waiting for backend health at $health"
$ok = $false
for ($i=0; $i -lt 30; $i++) {
    Start-Sleep -Seconds 2
    try {
        $r = Invoke-WebRequest $health -UseBasicParsing -TimeoutSec 5
        if ($r.StatusCode -eq 200) { $ok = $true; break }
    } catch {}
}
if ($ok) {
    Write-Host "== Backend is UP ==" -ForegroundColor Green
    Write-Host "   Health:   http://localhost:8000/health"
    Write-Host "   Dolibarr: http://localhost:8282 (login: admin / password: ChangeThisAdmin!)"
} else {
    Write-Warning "Backend didn't become healthy in time. Check logs: docker compose logs -f"
}
