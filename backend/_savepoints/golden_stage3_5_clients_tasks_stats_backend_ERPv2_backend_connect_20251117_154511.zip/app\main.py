from __future__ import annotations

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app import doliproxy, tasks_extra, stats

app = FastAPI(title="ERPv2 backend connect")

# CORS so that front on localhost can call backend
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Routers with Dolibarr proxy, extra task reports and stats
app.include_router(doliproxy.router)
app.include_router(tasks_extra.router)
app.include_router(stats.router)


# ---- Simple built-in endpoints ----

@app.get("/health")
async def health():
    return {"status": "ok"}


@app.get("/config")
async def config():
    # Minimal config used by front and smoke scripts
    return {
        "backend_base": "http://host.docker.internal:8000",
        "dolibarr_base": "http://host.docker.internal:8282",
    }


# Basic task endpoints for front dashboards

@app.get("/api/tasks")
async def tasks_all():
    # For now return empty list
    return []


@app.get("/api/tasks/today")
async def tasks_today():
    # For now return empty list
    return []


@app.api_route("/api/tasks/{task_id}/status", methods=["GET", "POST"])
async def task_status(task_id: int):
    # Stub status endpoint
    return {"id": task_id, "status": "unknown"}