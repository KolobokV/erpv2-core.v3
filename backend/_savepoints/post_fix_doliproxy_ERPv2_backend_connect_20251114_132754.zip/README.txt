ERPv2 Backend Connector — Stability Pack (v1.1.1)
