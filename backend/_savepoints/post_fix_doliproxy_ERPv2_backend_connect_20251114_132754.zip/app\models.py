﻿from __future__ import annotations
from sqlalchemy import Column, String, DateTime, Boolean, Enum
from sqlalchemy.dialects.sqlite import BLOB
from sqlalchemy.types import TEXT
from sqlalchemy.orm import Mapped, mapped_column
from datetime import datetime, timezone
import uuid
from .db import Base

def now_utc() -> datetime:
    return datetime.now(timezone.utc)

class Task(Base):
    __tablename__ = "tasks"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    title: Mapped[str] = mapped_column(String(500), nullable=False)
    description: Mapped[str] = mapped_column(TEXT, nullable=True)
    client_id: Mapped[str] = mapped_column(String(64), nullable=True)
    assigned_to: Mapped[str] = mapped_column(String(64), nullable=True)
    status: Mapped[str] = mapped_column(String(32), default="not_started")  # not_started | in_progress | completed | postponed
    priority: Mapped[str] = mapped_column(String(16), default="medium")     # low | medium | high | urgent
    deadline: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    tags: Mapped[str] = mapped_column(String(512), default="[]")
    is_auto_generated: Mapped[bool] = mapped_column(Boolean, default=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now_utc)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now_utc)
