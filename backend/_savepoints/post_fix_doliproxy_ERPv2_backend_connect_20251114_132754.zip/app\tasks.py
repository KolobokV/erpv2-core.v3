﻿from __future__ import annotations
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field
from typing import Optional, List
from sqlalchemy.orm import Session
from datetime import datetime, date, timedelta, timezone

from .db import Base, engine, get_db
from .models import Task

Base.metadata.create_all(bind=engine)

router = APIRouter(prefix="/api/tasks", tags=["tasks"])

# --- Schemas ---
class TaskCreate(BaseModel):
    title: str
    description: Optional[str] = None
    client_id: Optional[str] = None
    assigned_to: Optional[str] = None
    priority: str = "medium"
    deadline: datetime

class TaskOut(BaseModel):
    id: str
    title: str
    description: Optional[str]
    client_id: Optional[str]
    assigned_to: Optional[str]
    status: str
    priority: str
    deadline: datetime
    tags: str
    is_auto_generated: bool
    created_at: datetime
    updated_at: datetime

    class Config:
        from_attributes = True

class StatusUpdate(BaseModel):
    status: str  # not_started | in_progress | completed | postponed

# --- Helpers ---
def utc_floor(dt: datetime) -> datetime:
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    return dt.astimezone(timezone.utc).replace(hour=0, minute=0, second=0, microsecond=0)

def utc_ceil(dt: datetime) -> datetime:
    d0 = utc_floor(dt)
    return d0 + timedelta(days=1)

# --- Endpoints ---
@router.get("", response_model=list[TaskOut])
def list_tasks(db: Session = Depends(get_db), limit: int = 100, status: Optional[str] = None):
    q = db.query(Task).order_by(Task.deadline.asc())
    if status:
        q = q.filter(Task.status == status)
    return q.limit(limit).all()

@router.get("/today", response_model=list[TaskOut])
def tasks_today(db: Session = Depends(get_db)):
    now = datetime.now(timezone.utc)
    start = utc_floor(now)
    end = utc_ceil(now)
    q = db.query(Task).filter(Task.deadline >= start, Task.deadline < end).order_by(Task.deadline.asc())
    return q.all()

@router.post("", response_model=TaskOut)
def create_task(payload: TaskCreate, db: Session = Depends(get_db)):
    t = Task(
        title=payload.title,
        description=payload.description,
        client_id=payload.client_id,
        assigned_to=payload.assigned_to,
        priority=payload.priority,
        deadline=payload.deadline,
    )
    db.add(t)
    db.commit()
    db.refresh(t)
    return t

@router.put("/{task_id}/status", response_model=TaskOut)
def update_status(task_id: str, upd: StatusUpdate, db: Session = Depends(get_db)):
    t = db.query(Task).filter(Task.id == task_id).first()
    if not t:
        raise HTTPException(status_code=404, detail="Task not found")
    t.status = upd.status
    t.updated_at = datetime.now(timezone.utc)
    db.commit()
    db.refresh(t)
    return t
