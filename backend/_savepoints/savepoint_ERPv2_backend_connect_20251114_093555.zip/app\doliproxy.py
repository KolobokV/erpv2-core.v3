﻿from fastapi import APIRouter, HTTPException
from fastapi.responses import JSONResponse
import httpx
from typing import Any
from .settings import DOLI_BASE_URL, read_api_key

router = APIRouter(prefix="", tags=["dolibarr-proxy"])

async def _call_dolibarr(path: str, params: dict | None = None, method: str = "GET", json: Any | None = None):
    api_key = read_api_key()
    if not api_key:
        raise HTTPException(status_code=500, detail="DOLI_API_KEY not set")
    headers = {"DOLAPIKEY": api_key}
    url = f"{DOLI_BASE_URL.rstrip('/')}/{path.lstrip('/')}"
    async with httpx.AsyncClient(timeout=20.0) as client:
        if method == "GET":
            r = await client.get(url, headers=headers, params=params)
        elif method == "POST":
            r = await client.post(url, headers=headers, params=params, json=json)
        elif method == "PUT":
            r = await client.put(url, headers=headers, params=params, json=json)
        elif method == "DELETE":
            r = await client.delete(url, headers=headers, params=params)
        else:
            raise HTTPException(status_code=500, detail="Unsupported method")
    if r.status_code >= 400:
        raise HTTPException(status_code=r.status_code, detail=r.text)
    try:
        return r.json()
    except Exception:
        return {"raw": r.text}

@router.get("/clients")
async def list_clients(limit: int = 50, page: int = 0):
    return await _call_dolibarr("thirdparties", params={"limit": limit, "page": page, "sortfield": "t.rowid", "sortorder": "ASC"})

@router.get("/invoices")
async def list_invoices(limit: int = 50, page: int = 0):
    return await _call_dolibarr("invoices", params={"limit": limit, "page": page, "sortorder": "DESC"})

@router.get("/products")
async def list_products(limit: int = 50, page: int = 0):
    return await _call_dolibarr("products", params={"limit": limit, "page": page, "sortorder": "ASC"})
